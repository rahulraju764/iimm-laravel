
<?php $__env->startSection('title', 'Manage Gallery'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-card">
        <div class="admin-card-header">
            <h3>Gallery Images</h3>
            <a href="<?php echo e(route('admin.galleries.create')); ?>" class="btn-success-sm"><i class='bx bx-plus'></i> Upload
                Image</a>
        </div>
        <div class="admin-card-body" style="padding:0;">
            <?php if($galleries->count()): ?>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Image</th>
                            <th>Title</th>

                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><img src="<?php echo e(asset('storage/' . $gallery->image)); ?>" class="table-img"></td>
                                <td style="color:var(--text-primary);font-weight:500;"><?php echo e($gallery->title ?? '—'); ?></td>

                                <td><span
                                        class="status-badge <?php echo e($gallery->status ? 'active' : 'inactive'); ?>"><?php echo e($gallery->status ? 'Active' : 'Inactive'); ?></span>
                                </td>
                                <td>
                                    <div class="actions-cell">
                                        <a href="<?php echo e(route('admin.galleries.edit', $gallery)); ?>" class="btn-warning-sm"><i
                                                class='bx bx-edit'></i></a>
                                        <form action="<?php echo e(route('admin.galleries.destroy', $gallery)); ?>" method="POST"
                                            onsubmit="return confirm('Delete?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button
                                                class="btn-danger-sm"><i class='bx bx-trash'></i></button></form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="pagination-wrapper" style="padding:20px;"><?php echo e($galleries->links()); ?></div>
            <?php else: ?>
                <div class="empty-state"><i class='bx bxs-image-alt'></i>
                    <p>No images in gallery.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iimm\app\resources\views/admin/galleries/index.blade.php ENDPATH**/ ?>