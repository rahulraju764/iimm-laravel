
<?php $__env->startSection('title', 'View Enquiry'); ?>

<?php $__env->startSection('content'); ?>
    <div class="detail-card">
        <div style="margin-bottom:20px;">
            <a href="<?php echo e(route('admin.enquiries.index')); ?>" class="btn-back"><i class='bx bx-arrow-back'></i> Back to
                Enquiries</a>
        </div>

        <div class="detail-row">
            <div class="detail-label">Name</div>
            <div class="detail-value"><?php echo e($enquiry->name); ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">Email</div>
            <div class="detail-value"><a href="mailto:<?php echo e($enquiry->email); ?>"
                    style="color:var(--primary-light);"><?php echo e($enquiry->email); ?></a></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">Phone</div>
            <div class="detail-value"><?php echo e($enquiry->phone ?? '—'); ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">Subject</div>
            <div class="detail-value"><?php echo e($enquiry->subject ?? '—'); ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">Date</div>
            <div class="detail-value"><?php echo e($enquiry->created_at->format('d M Y, h:i A')); ?></div>
        </div>
        <div class="detail-row">
            <div class="detail-label">Message</div>
            <div class="detail-value"><?php echo e($enquiry->message ?? 'No message.'); ?></div>
        </div>

        <div style="margin-top:24px;">
            <form action="<?php echo e(route('admin.enquiries.destroy', $enquiry)); ?>" method="POST"
                onsubmit="return confirm('Delete this enquiry?')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn-danger-sm"><i class='bx bx-trash'></i> Delete Enquiry</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iimm\app\resources\views/admin/enquiries/show.blade.php ENDPATH**/ ?>