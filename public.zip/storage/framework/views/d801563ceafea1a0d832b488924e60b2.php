
<?php $__env->startSection('title', 'Upload Image'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-card">
        <div class="admin-card-header">
            <h3>Upload Gallery Image</h3>
        </div>
        <div class="admin-card-body">
            <?php if($errors->any()): ?>
            <div class="alert-error"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><?php endif; ?>
            <form action="<?php echo e(route('admin.galleries.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-grid">
                    <div class="admin-form-group"><label>Title</label><input type="text" name="title"
                            class="admin-form-control" value="<?php echo e(old('title')); ?>"></div>

                    <div class="admin-form-group"><label>Image *</label><input type="file" name="image"
                            class="admin-form-control" accept="image/*" required></div>
                    <div class="admin-form-group">
                        <div class="form-check"><input type="checkbox" name="status" id="status" value="1" checked><label
                                for="status">Active</label></div>
                    </div>
                </div>
                <div class="form-actions"><button type="submit" class="btn-admin-primary btn-sm">Upload</button><a
                        href="<?php echo e(route('admin.galleries.index')); ?>" class="btn-back">Cancel</a></div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iimm\app\resources\views/admin/galleries/create.blade.php ENDPATH**/ ?>