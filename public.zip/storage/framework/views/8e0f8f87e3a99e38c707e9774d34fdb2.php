

<?php $__env->startSection('meta'); ?>
	<title><?php echo e($blog->title); ?> | IIMM Cochin</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description"
		content="Join Kerala’s most trusted ERP course and become SAP-certified. Learn key modules with professionals." />
	<meta name="keywords" content="SAP Supply chain Management, Certification courses in kerala" />
	<meta property="og:locale" content="en_IN" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="SAP Supply Chain Management Certification | Top Courses in Kerala" />
	<meta property="og:url" content="<?php echo e(route('blog-details', ['slug' => $blog->slug])); ?>" />
	<meta property="og:site_name" content="Indobritco" />
	<meta property="og:image" content="<?php echo e(asset('storage/' . $blog->image)); ?>" />
	<meta property="og:image:width" content="1200" />
	<meta property="og:image:height" content="550" />
	<meta property="og:description" content="<?php echo e(Str::limit(strip_tags($blog->content), 150)); ?>" />
	<meta name="robots" content="index, follow" />
	<link rel="canonical" href="<?php echo e(route('blog-details', ['slug' => $blog->slug])); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<!-- Start Main Banner -->
	<section class="main-banner" style="background-image: url(<?php echo e(asset('assets/img/banner/event-banner.webp')); ?>);">
		<div class="container">
			<div class="row">
				<div class="col-xl-12 text-center">
					<h2>Blog Details</h2>
					<p>
						<a href="<?php echo e(route('home')); ?>">Home</a> <i class='bx bx-chevrons-right'></i>
						<?php echo e($blog->title); ?>

					</p>
				</div>
			</div>
		</div>
	</section>
	<!-- End Main Banner -->

	<!-- START Blog Grid -->
	<section class="blog-details section-padding">
		<div class="container">
			<div class="row">
				<div class="col-xl-8 col-lg-8 col-md-12 col-12 wow fadeIn">
					<div class="post-inner">
						<div class="post-image">
							<img src="<?php echo e(asset('storage/' . $blog->image)); ?>" class="img-fluid" alt="<?php echo e($blog->title); ?>">
						</div>

						<div class="entry-content">
							<h2><?php echo e($blog->title); ?></h2>
							<p>
								<?php echo $blog->content; ?>

							</p>
						</div>
					</div><!-- End post-inner -->
				</div><!-- END Col -->

				<!--<div class="col-xl-4 col-lg-4 col-md-12 col-12 sidebar wow fadeIn">
									<div class="widget popular-posts-widget">
										<h3 class="widget-title">Popular Posts</h3>
										<div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
											<?php $__currentLoopData = $popularPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li>
													<a class="nav-link" href="<?php echo e(route('blog-details', ['slug' => $post->slug])); ?>">
														<div class="float-start ppimage">
															<img src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="<?php echo e($post->title); ?>">
														</div>
														<div class="ppcontent">
															<h4><?php echo e($post->title); ?></h4>
														</div>
													</a>
												</li>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									</div>
								</div>-->

				<!-- END Col -->


			</div>
		</div>
	</section>
	<!-- END Blog Details -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iimm\app\resources\views/pages/blog-details.blade.php ENDPATH**/ ?>