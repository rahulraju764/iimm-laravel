
<?php $__env->startSection('title', 'Enquiries'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-card">
        <div class="admin-card-header">
            <h3>All Enquiries</h3>
        </div>
        <div class="admin-card-body" style="padding:0;">
            <?php if($enquiries->count()): ?>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Subject</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td style="color:var(--text-primary);font-weight:500;"><?php echo e($enq->name); ?></td>
                                <td><?php echo e($enq->email); ?></td>
                                <td><?php echo e($enq->phone ?? '—'); ?></td>
                                <td><?php echo e($enq->subject ?? '—'); ?></td>
                                <td><span
                                        class="status-badge <?php echo e($enq->is_read ? 'read' : 'unread'); ?>"><?php echo e($enq->is_read ? 'Read' : 'Unread'); ?></span>
                                </td>
                                <td><?php echo e($enq->created_at->format('d M Y')); ?></td>
                                <td>
                                    <div class="actions-cell">
                                        <a href="<?php echo e(route('admin.enquiries.show', $enq)); ?>" class="btn-info-sm"><i
                                                class='bx bx-show'></i></a>
                                        <form action="<?php echo e(route('admin.enquiries.destroy', $enq)); ?>" method="POST"
                                            onsubmit="return confirm('Delete?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button
                                                class="btn-danger-sm"><i class='bx bx-trash'></i></button></form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="pagination-wrapper" style="padding:20px;"><?php echo e($enquiries->links()); ?></div>
            <?php else: ?>
                <div class="empty-state"><i class='bx bxs-envelope'></i>
                    <p>No enquiries yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iimm\app\resources\views/admin/enquiries/index.blade.php ENDPATH**/ ?>