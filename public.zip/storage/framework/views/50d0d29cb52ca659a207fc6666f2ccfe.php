
<?php $__env->startSection('title', 'Applications'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-card">
        <div class="admin-card-header">
            <h3>All Applications</h3>
        </div>
        <div class="admin-card-body" style="padding:0;">
            <?php if($applications->count()): ?>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Course</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td style="color:var(--text-primary);font-weight:500;">
                                    <?php echo e($app->first_name); ?> <?php echo e($app->last_name); ?>

                                </td>
                                <td><?php echo e($app->course_name); ?></td>
                                <td><?php echo e($app->email); ?></td>
                                <td><?php echo e($app->phone ?? '—'); ?></td>
                                <td><span
                                        class="status-badge <?php echo e($app->is_read ? 'read' : 'unread'); ?>"><?php echo e($app->is_read ? 'Read' : 'Unread'); ?></span>
                                </td>
                                <td><?php echo e($app->created_at->format('d M Y')); ?></td>
                                <td>
                                    <div class="actions-cell">
                                        <a href="<?php echo e(route('admin.applications.show', $app)); ?>" class="btn-info-sm"><i
                                                class='bx bx-show'></i></a>
                                        <form action="<?php echo e(route('admin.applications.destroy', $app)); ?>" method="POST"
                                            onsubmit="return confirm('Delete?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn-danger-sm"><i class='bx bx-trash'></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="pagination-wrapper" style="padding:20px;"><?php echo e($applications->links()); ?></div>
            <?php else: ?>
                <div class="empty-state"><i class='bx bxs-file-doc'></i>
                    <p>No applications yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iimm\app\resources\views/admin/applications/index.blade.php ENDPATH**/ ?>