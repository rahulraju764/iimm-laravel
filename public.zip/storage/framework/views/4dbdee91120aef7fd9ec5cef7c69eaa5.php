

<?php $__env->startSection('meta'); ?>
    <title>404 - Page Not Found | IIMM Cochin</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h1 class="display-1">404</h1>
                    <h2>Page Not Found</h2>
                    <p class="lead">The page you are looking for might have been removed, had its name changed, or is
                        temporarily unavailable.</p>
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary mt-3">Go to Homepage</a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iimm\app\resources\views/errors/404.blade.php ENDPATH**/ ?>