
<?php $__env->startSection('title', 'Manage Courses'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-card">
        <div class="admin-card-header">
            <h3>All Courses</h3>
            <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn-success-sm"><i class='bx bx-plus'></i> Add Course</a>
        </div>
        <div class="admin-card-body" style="padding:0;">
            <?php if($courses->count()): ?>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Image</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <?php if($course->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $course->image)); ?>" class="table-img" alt="">
                                    <?php else: ?>
                                        <span style="color:var(--text-muted);">—</span>
                                    <?php endif; ?>
                                </td>
                                <td style="color:var(--text-primary); font-weight:500;"><?php echo e($course->title); ?></td>
                                <td><?php echo e($course->category ?? '—'); ?></td>
                                <td><?php echo e($course->duration ?? '—'); ?></td>
                                <td>
                                    <span class="status-badge <?php echo e($course->status ? 'active' : 'inactive'); ?>">
                                        <?php echo e($course->status ? 'Active' : 'Inactive'); ?>

                                    </span>
                                </td>
                                <td>
                                    <div class="actions-cell">
                                        <a href="<?php echo e(route('admin.courses.edit', $course)); ?>" class="btn-warning-sm"><i
                                                class='bx bx-edit'></i></a>
                                        <form action="<?php echo e(route('admin.courses.destroy', $course)); ?>" method="POST"
                                            onsubmit="return confirm('Delete this course?')">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn-danger-sm"><i class='bx bx-trash'></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="pagination-wrapper" style="padding:20px;"><?php echo e($courses->links()); ?></div>
            <?php else: ?>
                <div class="empty-state">
                    <i class='bx bxs-book-open'></i>
                    <p>No courses found. Click "Add Course" to create one.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iimm\app\resources\views/admin/courses/index.blade.php ENDPATH**/ ?>