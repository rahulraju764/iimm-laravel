<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Login - IIMM</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin.css')); ?>">
</head>

<body class="admin-body">

    <div class="admin-login-wrapper">
        <div class="login-card">
            <div class="logo-area">
                <h1>IIMM Admin</h1>
                <p>Indian Institute of Materials Management</p>
            </div>

            <?php if(session('success')): ?>
                <div class="alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert-error">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('admin.login.submit')); ?>">
                <?php echo csrf_field(); ?>
                <div class="admin-form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" class="admin-form-control" placeholder="admin@iimm.com"
                        value="<?php echo e(old('email')); ?>" required autofocus>
                </div>

                <div class="admin-form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="admin-form-control"
                        placeholder="Enter your password" required>
                </div>

                <button type="submit" class="btn-admin-primary">Sign In</button>
            </form>
        </div>
    </div>

</body>

</html><?php /**PATH C:\xampp\htdocs\iimm\app\resources\views/admin/login.blade.php ENDPATH**/ ?>