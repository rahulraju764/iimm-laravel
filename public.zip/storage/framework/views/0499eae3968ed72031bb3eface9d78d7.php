

<?php $__env->startSection('meta'); ?>
	<title>Contact Us - IIMM</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<!-- Start Main Banner -->
	<section class="main-banner" style="background-image: url(<?php echo e(asset('assets/img/banner/logestic%20450-4.webp')); ?>);">
		<div class="container">
			<div class="row">
				<div class="col-xl-12 text-center">
					<h2>Enquiry Form</h2>
					<p>
						<a href="<?php echo e(route('home')); ?>">Home</a> <i class='bx bx-chevrons-right'></i> enquiry form
					</p>
				</div>
			</div>
		</div>
	</section>
	<!-- End Home Banner -->

	<!-- Start Contact Us -->
	<section class="Enquiry_us">
		<div class="container">
			<div class="row">

				<div class="col-xl-8 mx-auto wow fadeIn">
					<div class="Enquiry-form align-self-center">

						<?php if(session('success')): ?>
							<div class="alert alert-success"
								style="background:#d4edda;color:#155724;padding:15px;border-radius:8px;margin-bottom:20px;">
								<?php echo e(session('success')); ?>

							</div>
						<?php endif; ?>

						<?php if($errors->any()): ?>
							<div class="alert alert-danger"
								style="background:#f8d7da;color:#721c24;padding:15px;border-radius:8px;margin-bottom:20px;">
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($error); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						<?php endif; ?>

						<form method="POST" action="<?php echo e(route('enquiry.submit')); ?>">
							<?php echo csrf_field(); ?>
							<div class="row">
								<div class="col-xl-6 col-12">
									<input type="text" name="name" placeholder="Enter Name" class="form-control form-box1"
										value="<?php echo e(old('name')); ?>" required>
								</div>

								<div class="col-xl-6 col-12">
									<input type="email" name="email" placeholder="Enter Email"
										class="form-control form-box1" value="<?php echo e(old('email')); ?>" required>
								</div>
								<div class="col-xl-12 col-12">
									<input type="text" name="phone" placeholder="Enter Phone" class="form-control form-box1"
										value="<?php echo e(old('phone')); ?>">
								</div>
								<div class="col-xl-12 col-12">
									<select name="subject" class="form-control form-box1">
										<option value="Courses and other enquiries" <?php echo e(old('subject') == 'Courses and other enquiries' ? 'selected' : ''); ?>>Courses and other enquiries</option>
										<option value="PG course enquiry" <?php echo e(old('subject') == 'PG course enquiry' ? 'selected' : ''); ?>>PG course enquiry</option>
										<option value="Short-term course enquiry" <?php echo e(old('subject') == 'Short-term course enquiry' ? 'selected' : ''); ?>>Short-term course enquiry</option>
										<option value="Seminar enquiry" <?php echo e(old('subject') == 'Seminar enquiry' ? 'selected' : ''); ?>>Seminar enquiry</option>
										<option value="Other enquiry" <?php echo e(old('subject') == 'Other enquiry' ? 'selected' : ''); ?>>Other enquiry</option>
									</select>
								</div>
								<div class="col-12">
									<textarea name="message" placeholder="Enter Message"
										class="form-control form-t form-box1"><?php echo e(old('message')); ?></textarea>
								</div>

								<div class="col-12">
									<input type="submit" class="bg_btn bt" value="Submit Now">
								</div>
							</div>
						</form>
					</div>
				</div> <!-- End Col -->

			</div>
		</div>
	</section>
	<!-- End Contact Us -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iimm\app\resources\views/pages/enquiry-form.blade.php ENDPATH**/ ?>