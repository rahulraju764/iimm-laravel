

<?php $__env->startSection('meta'); ?>
    <title>IIMM Cochin | Best courses for career</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content=" Advance your career with IIMM Cochin's professional courses in supply chain, logistics, and materials management. Choose from diploma, certification, and training programs." />
    <meta name="keywords" content=" career oriented," />
    <meta property="og:locale" content="en_IN" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content=" Best Career-Oriented Courses" />
    <meta property="og:url" content="PAGE_URL" />
    <meta property="og:site_name" content="Indobritco" />
    <meta property="og:image" content="#" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="550" />
    <meta property="og:description" content="We are providing industry-recognized short-term and long-term programs in supply chain and materials management at IIMM Cochin." />
    <meta name="robots" content="index, follow" />
    <link rel="canonical" href="#">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Main Banner -->
    <section class="main-banner" style="background-image: url(<?php echo e(asset('assets/img/banner/event-banner.webp')); ?>);">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 text-center">
                    <h2>Application Form</h2>
                    <p>
                        <a href="<?php echo e(route('home')); ?>">Home</a> <i class='bx bx-chevrons-right'></i>Application Form
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!-- End Main Banner -->

    <section class="application-form-section">
        <div class="container">
            <div class="application-form">
                <div class="section-title about-title  app-form-title wow animated fadeIn ">
                    <h2> Application For Short Term Course</h2>
                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success" style="background:#d4edda;color:#155724;padding:15px;border-radius:8px;margin-bottom:20px;max-width:900px;margin-left:auto;margin-right:auto;">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger" style="background:#f8d7da;color:#721c24;padding:15px;border-radius:8px;margin-bottom:20px;max-width:900px;margin-left:auto;margin-right:auto;">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($error); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('application.submit')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-xl-10 mx-auto">
                            <div class="iimm-application">
                                <div class="row">

                                    <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="app-detail">
                                            <label for="" class="form-label">First Name</label>
                                            <input type="text" name="first_name" placeholder="Enter First Name" class="form-control form-box1" value="<?php echo e(old('first_name')); ?>" required>
                                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="app-detail">
                                            <label for="" class="form-label">Last Name</label>
                                            <input type="text" name="last_name" placeholder="Enter Last Name" class="form-control form-box1" value="<?php echo e(old('last_name')); ?>">
                                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="app-detail">

                                            <label for="" class="form-label gen-label">Gender</label>
                                            <div class="Gender-section">
                                                <input type="radio" name="gender" value="male" <?php echo e(old('gender') == 'male' ? 'checked' : ''); ?>>
                                                <label for="">Male</label>

                                                <input type="radio" name="gender" value="female" <?php echo e(old('gender') == 'female' ? 'checked' : ''); ?>>
                                                <label for="">Female</label>
                                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="app-detail">

                                            <label for="" class="form-label">Address</label>
                                            <textarea name="address" cols="5" rows="5" class="form-control form-box1"><?php echo e(old('address')); ?></textarea>
                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="app-detail">

                                            <label for="" class="form-label">Mobile Number</label>
                                            <input type="text" name="phone" placeholder="Enter Mobile Number" class="form-control form-box1" value="<?php echo e(old('phone')); ?>">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="app-detail">

                                            <label for="" class="form-label">Email</label>
                                            <input type="email" name="email" placeholder="Enter Email" class="form-control form-box1" value="<?php echo e(old('email')); ?>" required>
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="app-detail">

                                            <label for="" class="form-label">Date Of Birth</label>
                                            <input type="date" name="dob" placeholder="Enter DOB" class="form-control form-box1" value="<?php echo e(old('dob')); ?>">
                                            <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="app-detail">

                                            <label for="" class="form-label">Passport Size Photo</label>
                                            <div class="choose-file">
                                                <label for="photo">Choose a file:</label>
                                                <input type="file" id="photo" name="photo">
                                                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <br><br>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="app-detail">

                                            <label for="" class="form-label">Qualification(Copy of
                                                Certificate to be attached)</label>
                                            <div class="choose-file">
                                                <label for="qualification_file">Choose a file:</label>
                                                <input type="file" id="qualification_file" name="qualification_file">
                                                <?php $__errorArgs = ['qualification_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <br><br>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="app-detail">

                                            <label for="" class="form-label">If employed, Name & Address</label>
                                            <input type="text" name="employer_info" placeholder="Enter Name & Adress" class="form-control form-box1" value="<?php echo e(old('employer_info')); ?>">
                                            <?php $__errorArgs = ['employer_info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>




                                    <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">

                                        <div class="app-detail bank-detail">
                                            <h5>OUR BANK DETAILS</h5>
                                            <p>Name of bank:<span>CSB Bank</span></p>
                                            <p>BRANCH:<span> Girinagar</span></p>
                                            <p>A/c No:<span>  018600531630190001</span></p>
                                            <p> IFSC Code:<span>CSBK0000186</span></p>

                                        </div>
                                        <div class="app-detail">

                                            <label for="" class="form-label">Admission sought for
                                                (Name of Course)</label>
                                            <input type="text" name="course_name" placeholder="Enter Course" class="form-control form-box1" value="<?php echo e(old('course_name')); ?>">
                                            <?php $__errorArgs = ['course_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="app-detail">
                                            <label for="" class="gen-label">How did you know about this course</label>
                                            <div class="proof">
                                                <input type="radio" name="referral_source" value="Person/Friend" <?php echo e(old('referral_source') == 'Person/Friend' ? 'checked' : ''); ?>>
                                                <label for="">Name of Person / Friend:</label>
                                            </div>
                                            <div class="proof">
                                                <input type="radio" name="referral_source" value="IIMM/Advertisement" <?php echo e(old('referral_source') == 'IIMM/Advertisement' ? 'checked' : ''); ?>>
                                                <label for="">IIMM / Advertisement</label>
                                            </div>
                                            <?php $__errorArgs = ['referral_source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        
                                        <div class="app-detail">
                                            <label for="" class="form-label">Date</label>
                                            <input type="date" name="application_date" class="form-control form-box1" value="<?php echo e(old('application_date')); ?>">
                                            <?php $__errorArgs = ['application_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="app-detail">
                                            <button type="submit" class="final-submit">submit</button>
                                        </div>



                                    </div>
                                    <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="app-detail">

                                            <label for="" class="form-label">Details of Fee Paid :Amount RS :
                                            </label>
                                            <input type="number" name="fee_amount" placeholder="Enter Amount" class="form-control form-box1" value="<?php echo e(old('fee_amount')); ?>">
                                            <?php $__errorArgs = ['fee_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="app-detail">

                                            <label for="" class="form-label"> Cheque Number
                                            </label>
                                            <input type="text" name="cheque_number" placeholder="Enter Number" class="form-control form-box1" value="<?php echo e(old('cheque_number')); ?>">
                                            <?php $__errorArgs = ['cheque_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="app-detail">

                                            <label for="" class="form-label"> Date
                                            </label>
                                            <input type="date" name="payment_date" placeholder="Enter Amount" class="form-control form-box1" value="<?php echo e(old('payment_date')); ?>">
                                            <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="app-detail">

                                            <label for="" class="form-label"> Name of Bank
                                            </label>
                                            <input type="text" name="bank_name" placeholder="Bank Name" class="form-control form-box1" value="<?php echo e(old('bank_name')); ?>">
                                            <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        
                                        <div class="app-detail">
                                            <label for="" class="form-label">Proof of payment made to bank (Pay in slip copy etc.)</label>
                                            <input type="file" id="payment_proof_file" name="payment_proof_file">
                                            <?php $__errorArgs = ['payment_proof_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <br>
                                        </div>

                                        <div class="app-detail">
                                            <label for="" class="gen-label">Attached proof of Transfer</label>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <select name="proof_attached" class=" form-select">
                                                        <option value="Yes" <?php echo e(old('proof_attached') == 'Yes' ? 'selected' : ''); ?>>Yes</option>
                                                        <option value="No" <?php echo e(old('proof_attached') == 'No' ? 'selected' : ''); ?>>No</option>
                                                    </select>
                                                    <?php $__errorArgs = ['proof_attached'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="text-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>


                                            </div>
                                        </div>

                                    </div>



                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iimm\app\resources\views/pages/application-form.blade.php ENDPATH**/ ?>