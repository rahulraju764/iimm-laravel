
<?php $__env->startSection('title', 'Manage Events'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-card">
        <div class="admin-card-header">
            <h3>All Events</h3>
            <a href="<?php echo e(route('admin.events.create')); ?>" class="btn-success-sm"><i class='bx bx-plus'></i> Add Event</a>
        </div>
        <div class="admin-card-body" style="padding:0;">
            <?php if($events->count()): ?>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Image</th>
                            <th>Title</th>
                            <th>Date</th>
                            <th>Location</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php if($event->image): ?><img src="<?php echo e(asset('storage/' . $event->image)); ?>" class="table-img"><?php else: ?>
                                <span style="color:var(--text-muted);">—</span> <?php endif; ?></td>
                                <td style="color:var(--text-primary);font-weight:500;"><?php echo e($event->title); ?></td>
                                <td><?php echo e($event->date ? $event->date->format('d M Y') : '—'); ?></td>
                                <td><?php echo e($event->location ?? '—'); ?></td>
                                <td><span
                                        class="status-badge <?php echo e($event->status ? 'active' : 'inactive'); ?>"><?php echo e($event->status ? 'Active' : 'Inactive'); ?></span>
                                </td>
                                <td>
                                    <div class="actions-cell">
                                        <a href="<?php echo e(route('admin.events.edit', $event)); ?>" class="btn-warning-sm"><i
                                                class='bx bx-edit'></i></a>
                                        <form action="<?php echo e(route('admin.events.destroy', $event)); ?>" method="POST"
                                            onsubmit="return confirm('Delete?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button
                                                class="btn-danger-sm"><i class='bx bx-trash'></i></button></form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="pagination-wrapper" style="padding:20px;"><?php echo e($events->links()); ?></div>
            <?php else: ?>
                <div class="empty-state"><i class='bx bxs-calendar-event'></i>
                    <p>No events found.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iimm\app\resources\views/admin/events/index.blade.php ENDPATH**/ ?>