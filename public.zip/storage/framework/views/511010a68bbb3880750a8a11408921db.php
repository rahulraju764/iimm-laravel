
<?php $__env->startSection('title', 'Edit Blog Post'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-card">
        <div class="admin-card-header">
            <h3>Edit Blog Post</h3>
        </div>
        <div class="admin-card-body">
            <?php if($errors->any()): ?>
            <div class="alert-error"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><?php endif; ?>
            <form action="<?php echo e(route('admin.blogs.update', $blog)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                <div class="form-grid">
                    <div class="admin-form-group"><label>Title *</label><input type="text" name="title"
                            class="admin-form-control" value="<?php echo e(old('title', $blog->title)); ?>" required></div>
                    <div class="admin-form-group"><label>Published Date</label><input type="date" name="published_at"
                            class="admin-form-control"
                            value="<?php echo e(old('published_at', $blog->published_at ? $blog->published_at->format('Y-m-d') : '')); ?>">
                    </div>
                    <div class="admin-form-group"><label>Image</label><input type="file" name="image"
                            class="admin-form-control" accept="image/*"><?php if($blog->image): ?>
                                <p style="margin-top:6px;color:var(--text-muted);font-size:12px;">Current:
                            <?php echo e(basename($blog->image)); ?></p><?php endif; ?>
                    </div>
                    <div class="admin-form-group">
                        <div class="form-check"><input type="checkbox" name="status" id="status" value="1" <?php echo e($blog->status ? 'checked' : ''); ?>><label for="status">Active</label></div>
                    </div>
                    <div class="admin-form-group full-width"><label>Content</label><textarea name="content"
                            class="admin-form-control"
                            style="min-height:200px;"><?php echo e(old('content', $blog->content)); ?></textarea></div>
                </div>
                <div class="form-actions"><button type="submit" class="btn-admin-primary btn-sm">Update Post</button><a
                        href="<?php echo e(route('admin.blogs.index')); ?>" class="btn-back">Cancel</a></div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\iimm\app\resources\views/admin/blogs/edit.blade.php ENDPATH**/ ?>