<?php

use Illuminate\Support\Facades\Route;

// Home
Route::get('/', function () {
    return view('pages.index');
})->name('home');

// About
Route::get('/about', function () {
    return view('pages.about');
})->name('about');

// Contact
Route::get('/contact', function () {
    return view('pages.contact');
})->name('contact');

// Courses
Route::get('/courses', function () {
    return view('pages.course');
})->name('course');

Route::get('/course-details', function () {
    return view('pages.course-details');
})->name('course-details');

Route::get('/logistics-course', function () {
    return view('pages.logistics-course');
})->name('logistics-course');

Route::get('/warehouse-course', function () {
    return view('pages.warehouse-course');
})->name('warehouse-course');

Route::get('/artificial', function () {
    return view('pages.artificial');
})->name('artificial');

Route::get('/sap', function () {
    return view('pages.sap');
})->name('sap');

Route::get('/pgmm', function () {
    return view('pages.pgmm');
})->name('pgmm');

Route::get('/pgdl', function () {
    return view('pages.pgdl');
})->name('pgdl');

Route::get('/long-course', function () {
    return view('pages.long-course');
})->name('long-course');

Route::get('/short-course', function () {
    return view('pages.short-course');
})->name('short-course');

// Blog
use App\Http\Controllers\PageController;
Route::get('/blog', [PageController::class, 'blog'])->name('blog');

Route::get('/blog-details/{slug}', [PageController::class, 'blogDetails'])->name('blog-details');

Route::get('/logistic-management-blog', function () {
    return view('pages.logistic-management-blog');
})->name('logistic-management-blog');

Route::get('/warehouse-management-blog', function () {
    return view('pages.warehouse-management-blog');
})->name('warehouse-management-blog');

Route::get('/materials-management', function () {
    return view('pages.materials-management');
})->name('materials-management');

// Event
use App\Models\Event;
Route::get('/event', function () {
    $events = Event::where('status', true)->latest()->paginate(9);
    return view('pages.event', compact('events'));
})->name('event');

// Gallery
Route::get('/gallery', [PageController::class, 'gallery'])->name('gallery');

// News
Route::get('/news', function () {
    return view('pages.news');
})->name('news');

// Career
Route::get('/career', function () {
    return view('pages.career');
})->name('career');

// Testimonials
Route::get('/testimonials', function () {
    return view('pages.testimonials');
})->name('testimonials');

// Members
Route::get('/members', function () {
    return view('pages.members');
})->name('members');

// Past Chairman Says
Route::get('/past-chairman-says', function () {
    return view('pages.past-chairman-says');
})->name('past-chairman-says');

// Disclaimer
Route::get('/disclaimer', function () {
    return view('pages.disclaimer');
})->name('disclaimer');

// Programmes
Route::get('/programmes', function () {
    return view('pages.programmes');
})->name('programmes');

// Forms
Route::get('/enquiry-form', function () {
    return view('pages.enquiry-form');
})->name('enquiry-form');

Route::get('/application-form', function () {
    return view('pages.application-form');
})->name('application-form');

Route::get('/life-time-form', function () {
    return view('pages.life-time-form');
})->name('life-time-form');

// Form Submissions
use App\Http\Controllers\FormController;
Route::post('/enquiry-form', [FormController::class, 'submitEnquiry'])->name('enquiry.submit');
Route::post('/application-form', [FormController::class, 'submitApplication'])->name('application.submit');
Route::post('/life-time-form', [FormController::class, 'submitMembership'])->name('membership.submit');

// ===== Admin Routes =====
use App\Http\Controllers\Admin\AdminAuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\CourseController;
use App\Http\Controllers\Admin\EventController;
use App\Http\Controllers\Admin\NewsController;
use App\Http\Controllers\Admin\BlogController;
use App\Http\Controllers\Admin\GalleryController;
use App\Http\Controllers\Admin\TestimonialController;
use App\Http\Controllers\Admin\CareerController;
use App\Http\Controllers\Admin\EnquiryController;
use App\Http\Controllers\Admin\ApplicationController;

// Admin Auth (guest)
Route::get('/admin/login', [AdminAuthController::class, 'showLogin'])->name('admin.login');
Route::post('/admin/login', [AdminAuthController::class, 'login'])->name('admin.login.submit');
Route::post('/admin/logout', [AdminAuthController::class, 'logout'])->name('admin.logout');

// Admin Panel (protected)
Route::prefix('admin')->middleware('admin')->name('admin.')->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard.index');

    Route::resource('courses', CourseController::class)->except(['show']);
    Route::resource('events', EventController::class)->except(['show']);
    Route::resource('news', NewsController::class)->except(['show']);
    Route::resource('blogs', BlogController::class)->except(['show']);
    Route::resource('galleries', GalleryController::class)->except(['show']);
    Route::resource('testimonials', TestimonialController::class)->except(['show']);
    Route::resource('careers', CareerController::class)->except(['show']);

    Route::get('enquiries', [EnquiryController::class, 'index'])->name('enquiries.index');
    Route::get('enquiries/{enquiry}', [EnquiryController::class, 'show'])->name('enquiries.show');
    Route::delete('enquiries/{enquiry}', [EnquiryController::class, 'destroy'])->name('enquiries.destroy');

    Route::get('applications', [ApplicationController::class, 'index'])->name('applications.index');
    Route::get('applications/{application}', [ApplicationController::class, 'show'])->name('applications.show');
    Route::delete('applications/{application}', [ApplicationController::class, 'destroy'])->name('applications.destroy');
});
